#pragma once

namespace calculadora1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::Button^  buttonsuma;
	private: System::Windows::Forms::Button^  buttonresta;
	private: System::Windows::Forms::Button^  buttonmulti;
	private: System::Windows::Forms::Button^  buttondivi;
	private: System::Windows::Forms::TextBox^  PrimerNumero;
	private: System::Windows::Forms::TextBox^  SegundoNumero;
	private: System::Windows::Forms::TextBox^  Respuesta;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;







	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->buttonsuma = (gcnew System::Windows::Forms::Button());
			this->buttonresta = (gcnew System::Windows::Forms::Button());
			this->buttonmulti = (gcnew System::Windows::Forms::Button());
			this->buttondivi = (gcnew System::Windows::Forms::Button());
			this->PrimerNumero = (gcnew System::Windows::Forms::TextBox());
			this->SegundoNumero = (gcnew System::Windows::Forms::TextBox());
			this->Respuesta = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// buttonsuma
			// 
			this->buttonsuma->Location = System::Drawing::Point(139, 139);
			this->buttonsuma->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->buttonsuma->Name = L"buttonsuma";
			this->buttonsuma->Size = System::Drawing::Size(89, 23);
			this->buttonsuma->TabIndex = 1;
			this->buttonsuma->Text = L"Suma";
			this->buttonsuma->UseVisualStyleBackColor = true;
			this->buttonsuma->Click += gcnew System::EventHandler(this, &Form1::buttonsuma_Click);
			// 
			// buttonresta
			// 
			this->buttonresta->Location = System::Drawing::Point(139, 168);
			this->buttonresta->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->buttonresta->Name = L"buttonresta";
			this->buttonresta->Size = System::Drawing::Size(89, 23);
			this->buttonresta->TabIndex = 2;
			this->buttonresta->Text = L"Resta";
			this->buttonresta->UseVisualStyleBackColor = true;
			this->buttonresta->Click += gcnew System::EventHandler(this, &Form1::buttonresta_Click);
			// 
			// buttonmulti
			// 
			this->buttonmulti->Location = System::Drawing::Point(139, 196);
			this->buttonmulti->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->buttonmulti->Name = L"buttonmulti";
			this->buttonmulti->Size = System::Drawing::Size(89, 23);
			this->buttonmulti->TabIndex = 3;
			this->buttonmulti->Text = L"Multiplicacion";
			this->buttonmulti->UseVisualStyleBackColor = true;
			this->buttonmulti->Click += gcnew System::EventHandler(this, &Form1::buttonmulti_Click);
			// 
			// buttondivi
			// 
			this->buttondivi->Location = System::Drawing::Point(139, 226);
			this->buttondivi->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->buttondivi->Name = L"buttondivi";
			this->buttondivi->Size = System::Drawing::Size(89, 23);
			this->buttondivi->TabIndex = 4;
			this->buttondivi->Text = L"Division";
			this->buttondivi->UseVisualStyleBackColor = true;
			this->buttondivi->Click += gcnew System::EventHandler(this, &Form1::buttondivi_Click);
			// 
			// PrimerNumero
			// 
			this->PrimerNumero->Location = System::Drawing::Point(59, 53);
			this->PrimerNumero->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->PrimerNumero->Name = L"PrimerNumero";
			this->PrimerNumero->Size = System::Drawing::Size(117, 20);
			this->PrimerNumero->TabIndex = 5;
			// 
			// SegundoNumero
			// 
			this->SegundoNumero->Location = System::Drawing::Point(208, 53);
			this->SegundoNumero->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->SegundoNumero->Name = L"SegundoNumero";
			this->SegundoNumero->Size = System::Drawing::Size(116, 20);
			this->SegundoNumero->TabIndex = 6;
			// 
			// Respuesta
			// 
			this->Respuesta->Location = System::Drawing::Point(139, 97);
			this->Respuesta->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->Respuesta->Name = L"Respuesta";
			this->Respuesta->Size = System::Drawing::Size(100, 20);
			this->Respuesta->TabIndex = 7;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(56, 38);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(76, 13);
			this->label1->TabIndex = 8;
			this->label1->Text = L"Primer Numero";
			this->label1->Click += gcnew System::EventHandler(this, &Form1::label1_Click_1);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(205, 38);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(90, 13);
			this->label2->TabIndex = 9;
			this->label2->Text = L"Segundo Numero";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(136, 81);
			this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(55, 13);
			this->label3->TabIndex = 10;
			this->label3->Text = L"Resultado";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(409, 283);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->Respuesta);
			this->Controls->Add(this->SegundoNumero);
			this->Controls->Add(this->PrimerNumero);
			this->Controls->Add(this->buttondivi);
			this->Controls->Add(this->buttonmulti);
			this->Controls->Add(this->buttonresta);
			this->Controls->Add(this->buttonsuma);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F));
			this->ForeColor = System::Drawing::Color::Black;
			this->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->Name = L"Form1";
			this->Text = L"Calculadora";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void label1_Click_1(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void buttonsuma_Click(System::Object^  sender, System::EventArgs^  e) {
			 double num1,num2,res;
			 num1=System::Convert::ToInt32(PrimerNumero->Text);//Asigna a la variable num1 la caja text Primer numero
		     num2=System::Convert::ToInt32(SegundoNumero->Text);
			 res=num1+num2;
			 Respuesta->Text=System::Convert::ToString(res);//Le asignamos a la casilla de respuesta lo que tenemos en la variable res
		 }
private: System::Void buttonresta_Click(System::Object^  sender, System::EventArgs^  e) {
			  double num1,num2,res;
			 num1=System::Convert::ToInt32(PrimerNumero->Text);
		     num2=System::Convert::ToInt32(SegundoNumero->Text);
			 res=num1-num2;
			 Respuesta->Text=System::Convert::ToString(res);

		 }
private: System::Void buttonmulti_Click(System::Object^  sender, System::EventArgs^  e) {
			 double num1,num2,res;
			 num1=System::Convert::ToInt32(PrimerNumero->Text);
		     num2=System::Convert::ToInt32(SegundoNumero->Text);
			 res=num1*num2;
			 Respuesta->Text=System::Convert::ToString(res);
		 }
private: System::Void buttondivi_Click(System::Object^  sender, System::EventArgs^  e) {
			 double num1,num2,res;
			 num1=System::Convert::ToInt32(PrimerNumero->Text);
		     num2=System::Convert::ToInt32(SegundoNumero->Text);
			 res=num1/num2;
			 Respuesta->Text=System::Convert::ToString(res);
		 }
};
}

