#include "StdAfx.h"
#include "Cola.h"
#include <iostream>

using namespace std;


Cola::Cola(void)
{
	ini=0;
	fin=0;
}


Cola::~Cola(void)
{
}

bool Cola::ColaVacia(void){
	bool b_aux;
	if(ini==fin){
		b_aux=true;
	}else{
		b_aux=false;
	}
return b_aux;
}

bool Cola::Encolar(int x){
	bool error;
	if(fin==MAX){
		error=false;
	}else{
		error=true;
		info[fin]=x;
		fin++;
		
	}
return error;
}

bool Cola::PrimeroCola(int &x){
	bool error;
	if(ColaVacia()==true){
		error=false;
	}else{
		error=true;
		x=info[ini];
	}
	return error;
}

bool Cola::Desencolar(){
	bool error;
	if(ColaVacia()==true){
		error=false;
	}
	else{
		error=true;
		ini++;
	}
	return error;
}

void Cola::mostrar(){
	for(int i=ini;i<fin;i++){
		cout<<"Info"<<"["<<i<<"]="<<info[i]<<endl;
	}
	}


		
	
	

