// ejemplocola.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Cola.h"
#include <iostream>
#include "conio.h"
#define MAX 100

using namespace std;

void main(){
	Cola c;
	int Cola[MAX],opc,x,p;
	do{
		cout<<"-----MENU-----"<<endl;
		cout<<"1-.Encolar"<<endl;
		cout<<"2-.Cola Primero"<<endl;
		cout<<"3-.Desencolar"<<endl;
		cout<<"4-.Mostrar"<<endl;
		cout<<"0-.Salir"<<endl;
		cout<<"Opcion"<<endl;
		cin>>opc;
		switch(opc){
		case 1:
			cout<<"Ingrese el valor";
			cin>>x;
			if((c.Encolar(x))==true){
				cout<<"Se agrego el valor a la cola"<<endl;
			}else{
				cout<<"Cola llena"<<endl;
			}
			break;
		case 2:
			if(c.PrimeroCola(p)==true){
				cout<<"El numero es: "<<p;
			}else{
				cout<<"Cola Vacia"<<endl;
			}
			break;
		case 3:
			if(c.Desencolar()==true){
				cout<<"Se elimino el Valor"<<endl;
			}else{
				cout<<"Cola Vacia"<<endl;
			}
			break;
		case 4:
			c.mostrar();
			break;
		case 0:
			cout<<"Salir"<<endl;
			break;
		default:
			cout<<"Opcion no valida";
			break;
		}
		getch();
	}while(opc!=0);
	system("cls");
	getch();
	system("pause");
}


	




		


