#pragma once
#define MAX 100
class Cola
{
private:
	int info[MAX];
	int ini,fin;
public:
	Cola(void);
	~Cola(void);
	bool Encolar(int x);
	bool Desencolar(void);
	bool PrimeroCola(int &x);
	bool ColaVacia(void);
	void mostrar();
};

