// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "conio.h"
#include "triangulo.h"

using namespace std;

int main(void) {
   Rectangulo Rect;
 
   Rect.setWidth(5);
   Rect.setHeight(7);
   triangulo t;
   t.setWidth(5);
   t.setHeight(8);
   
   // Muestra el �rea de un rectangulo
   cout << "Total area: " << Rect.getArea() << endl;
   cout << "Total area del triangulo es: " << t.getarea() << endl;
   getch();
   return 0;
}