#include "StdAfx.h"
#include "triangulo.h"


triangulo::triangulo(void)
{
}


triangulo::~triangulo(void)
{
}
