#pragma once
#include "Shape.h"

class triangulo:
public Shape
{

public:
	triangulo(void);
	~triangulo(void);
	int getarea(){
		return (width * height/2);
	}
};

