#include "StdAfx.h"
#include "pila.h"


pila::pila()
{sp = STACK_SIZE-1;
items = 0;
itemsize = 1;
}


pila::~pila(void)
{
}
int pila::size ()
{ return items; }

int pila::empty ()
{ return items == 0; }


int pila:: put(char d)
	{
		if ( sp >= 0) {
			pila1[sp] = d;
			sp --;
			items ++;
		}
		return d;
}
int pila::get()
	{
		if ( ! empty() ) {
			sp ++;
			items --;
		}
		return pila1[sp];
}