#pragma once
#include <iostream>
#include "pila.h"
// Manejar el formato de la clase
using namespace std;
 
#define STACK_SIZE 256 /* capacidad m�xima */
typedef char arreglo[STACK_SIZE];
 
class pila {
	 
	int sp; /* puntero de lectura/escritura */
	int items; /* n�mero de elementos en lista */
	int itemsize; /* tama�o del elemento */
	arreglo pila1;	 /* el arreglo */
	 
	public:
		// constructor
		pila();
	 
		// destructor
		~pila();
	 
	/* regresa el n�mero de elementos en lista */
	int size() ;
	 
	/* regresa 1 si no hay elementos en la lista, o sea, si la lista est� vacia */
	int empty() ;
	 
	/* insertar elemento a la lista */
	int put(char d);
	
	 
	/* retirar elemento de la lista */
	int get();
	
}; // fin de clase Stack