// pilas.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include <iostream>
#include "pila.h"
using namespace std;
#define STACK_SIZE 256 

 
void main()
{   int d;
    pila s;  // s es un objeto (instancia) de la clase Stack
 
    
	
	// llenando la pila
    for (d='A'; d<='Z'; d++)
	s.put(d);
    cout << "Items =" << s.size() << endl;
 
    // vaciando la pila
    while ( s.size() ) 

    cout << (char)s.get() << " ";
    cout << "\nPara terminar oprima <Enter>...";
    cin.get();
   
getch();
}